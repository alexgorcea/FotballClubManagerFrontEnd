import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Card, ListGroup, Row, Col } from 'react-bootstrap';
import api from '../api/axiosConfig';

function Review() {
  const { reviewId } = useParams();
  const [review, setReview] = useState(null);

  useEffect(() => {
    const fetchReview = async () => {
      try {
        const response = await api.get(`/reviews/${reviewId}`);
        setReview(response.data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchReview();
  }, [reviewId]);

  if (!review) return <p>Loading review...</p>;

  return (
    <Card className="m-4">
      <Card.Header>Match Review</Card.Header>
      <Card.Body>
        <Row>
          <Col>
            <ListGroup variant="flush">
              <ListGroup.Item><strong>Home Score:</strong> {review.homeTeamScore}</ListGroup.Item>
              <ListGroup.Item><strong>Away Score:</strong> {review.awayTeamScore}</ListGroup.Item>
              <ListGroup.Item><strong>Winner Team ID:</strong> {review.winnerTeamId}</ListGroup.Item>
            </ListGroup>
          </Col>
          <Col>
            <h5>Spectators</h5>
            <ListGroup variant="flush">
              {Object.entries(review.spectators).map(([key, value]) => (
                <ListGroup.Item key={key}><strong>{key}:</strong> {value}</ListGroup.Item>
              ))}
            </ListGroup>
          </Col>
          <Col>
            <h5>Ticket Earnings</h5>
            <ListGroup variant="flush">
              {Object.entries(review.ticketEarning).map(([key, value]) => (
                <ListGroup.Item key={key}><strong>{key}:</strong> ${value.toFixed(2)}</ListGroup.Item>
              ))}
            </ListGroup>
          </Col>
        </Row>
      </Card.Body>
    </Card>
  );
}

export default Review;
